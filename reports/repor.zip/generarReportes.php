<?php
session_start();
include '../conexion/Conexion.php';
include '../utils/encriptacion.php';
include '../includes/app.php';
incluirTemplates('header', $accesoRolAdmin);
?>

<!-- Cuerpo de la aplicación -->
<div class="app-body">
    <div class="container mt-5">
        <div class="row mb-4">
            <div class="col-12 text-center">
                <h1 class="display-5 text-primary">Panel de Reportes</h1>
                <p class="text-muted">Selecciona un reporte para visualizar</p>
            </div>
        </div>
        <div class="row">
            <?php 
            $reportes = [
                ["Reporte de Ventas", "ventas.php", "ventas.png"],
                ["Reporte de Compras", "compras.php", "compras.png"],
                ["Reporte de Usuarios", "usuarios.php", "usuarios.png"],
                ["Reporte de Productos", "productos.php", "productos.png"],
                ["Reporte Financiero", "finanzas.php", "finanzas.png"]
            ];

            foreach ($reportes as $reporte) {
                echo "
                <div class='col-lg-4 col-md-6 mb-4'>
                    <div class='card report-card shadow-lg'>
                        <img src='../../assets/images/reports/{$reporte[2]}' class='card-img-top' alt='{$reporte[0]}'>
                        <div class='card-body text-center'>
                            <h5 class='card-title'>{$reporte[0]}</h5>
                            <a href='{$reporte[1]}' class='btn btn-primary w-100'>Ver Reporte</a>
                        </div>
                    </div>
                </div>";
            }
            ?>
        </div>
    </div>
</div>
<!-- Fin del cuerpo de la aplicación -->

<!-- Pie de página -->
<div class="app-footer">
    <div class="container text-center mt-5">
        <span>© Todos los derechos reservados Facultad Multidisciplinaria Paracentral - <?php echo date('Y'); ?></span>
    </div>
</div>

<!-- Scripts -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.1/dist/js/bootstrap.bundle.min.js"></script>
